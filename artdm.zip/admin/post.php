<?php
// 检查是否触发了还原操作
if (isset($_GET['act']) && $_GET['act'] == 'reset') {
    $sourceFile = 'bak.data.php'; // 源文件路径
    $destinationFile = 'data.php'; // 目标文件路径

    // 尝试复制文件
    if (copy($sourceFile, $destinationFile)) {
        // 复制成功
        echo "{code:1,msg:'还原成功'}";
    } else {
        // 复制失败
        error_log("文件复制失败：从 $sourceFile 到 $destinationFile");
        echo "{code:0,msg:'还原失败！请检查文件路径和权限'}";
    }
    exit; // 结束脚本执行
}

// 检查是否触发了设置保存操作
if (isset($_GET['act']) && $_GET['act'] == 'setting' && isset($_POST['edit']) && $_POST['edit'] == 1) {
    $datas = $_POST;
    $data = $datas['MIZHI'];

    // 尝试写入数据到文件
    if (file_put_contents('data.php', "<?php\n \$MIZHI =  " . var_export($data, true) . ";\n?>")) {
        // 写入成功
        echo "{code:1,msg:'保存成功'}";
    } else {
        // 写入失败
        error_log("文件写入失败：data.php");
        echo "<script>alert('修改失败！可能是文件权限问题，请给予data.php写入权限！');location.href='" . $_SERVER["HTTP_REFERER"] . "';</script>";
    }
    $MIZHI = $data;
}
?>